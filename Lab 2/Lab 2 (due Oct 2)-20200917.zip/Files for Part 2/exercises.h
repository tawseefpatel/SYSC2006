/* SYSC 2006 Lab 2, Part 2.
 *
 * Prototypes for the functions that will be coded during the lab.
 * DO NOT MODIFY THIS FILE! 
 */
 
int factorial(int n);
int ordered_subsets(int n, int k);
int binomial(int n, int k);
double cosine(double x, int n);
