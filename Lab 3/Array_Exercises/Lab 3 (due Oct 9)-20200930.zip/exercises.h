/* SYSC 2006 Lab 3. 
 *
 * Declarations for the functions that will be coded during the lab.
 * Do not modify this file.
 */

double avg_magnitude(double x[], double n);
double avg_power(double x[], double n);
double max(double arr[], int n);
double min(double arr[], int n);
void normalize(double x[], int n);

